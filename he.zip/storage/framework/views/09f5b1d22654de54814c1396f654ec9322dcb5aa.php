  

  <?php $__env->startSection('class'); ?>
page-product grid-view <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>     

       
        <!-- MAIN -->
        <main class="site-main product-list product-grid">
            <div class="container">
                <ol class="breadcrumb-page">
                    <li><a href="<?php echo e(route('/')); ?>">Home </a></li>
                    <li class="active"><a href="#">Search Results  </a></li>
                </ol>
            </div>
            <div class="container">
                <div class="row">
                  <br><br><h1>Search Results</h1><br>
                <h3><p><?php echo e($total); ?> result(s) Found</p></h3>


                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="product-item style1 col-md-3 col-md-offset-1 col-sm-6 col-xs-6 padding-0">
                        <div class="product-inner equal-elem">
                            <div class="product-thumb">
                                <div class="thumb-inner">
                                    <a href="<?php echo e(route('shop.show',$product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" alt="b2" style="height: 214px; width: 214px;"></a>
                                </div>
                                <?php if($product->discount): ?>
                                <span class="onsale">-<?php echo e($product->discount); ?>%</span>
                                <?php endif; ?>
                                
                            </div>
                            <div class="product-innfo">
                                <div class="product-name" style="height:60px"><a href="<?php echo e(route('shop.show',$product->slug)); ?>" ><?php echo e(substr($product->name,0,90)); ?></a></div>
                                <span class="price">
                                    <ins>Rs.<?php echo e($product->new_price); ?></ins>
                                    <?php if($product->old_price): ?>
                                    <del>Rs.<?php echo e($product->old_price); ?></del>
                                    <?php endif; ?>

                                </span>
                                <div class="group-btn-hover">
                                    <div class="inner">
                                        <div style="float: left;">
                                        <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />    
                                                        <input type="hidden" name="price" value="<?php echo e($product->new_price); ?>" />
                                                        <input type="hidden" name="qty" value="1" />
                                                        <button type="submit" class="add-to-cart">Add to cart</button>
                                                    </form>
                                                </div>
                                                <div style="float: right;">
                                                    <form action="<?php echo e(route('wishlist.store',$product->id)); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                                        <input type="hidden" name="price" value="<?php echo e($product->new_price); ?>" />
                                                        <button class="wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></button>

                                                    </form>
                                                </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <br><br><br>
                            <div><h2></h2></div>
                        <?php endif; ?>


                        <div class="clearfix"> </div>
                    </div>
                <div class="pull-right">
                    <?php echo e($products->appends(request()->input())->links()); ?>

                </div>
                <div class="clearfix"> </div>

                </div>
            </div>
            </div>

            <?php echo $__env->make('includes.recommendation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            
            
        </main><!-- end MAIN -->
        

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>