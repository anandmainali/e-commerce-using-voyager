  

  <?php $__env->startSection('class'); ?>
  page-product grid-view <?php $__env->stopSection(); ?>

  <?php $__env->startSection('content'); ?>     


  <!-- MAIN -->
  <main class="site-main product-list product-grid">
    <div class="container">
        <ol class="breadcrumb-page">
            <li><a href="<?php echo e(route('/')); ?>">Home </a></li>
            <li class="active"><a href="#">Sell Products  </a></li>
        </ol>
    </div>
    <br><br>
  
   
    <div class="container">

        <div class="row">
          <a href="<?php echo e(route('sellUs.create')); ?>" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Add Product</a><br><br>
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
      <th scope="col">Status</th>
      <th scope="col">Image</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  
  <tbody>
    <?php if(count($products) > 0): ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td scope="row"><?php echo e(++$key); ?></th>
      <td><?php echo e($product->name); ?></td>
      <td><?php echo e($product->new_price); ?></td>
      <td>
        <?php if($product->status == 0): ?>
      <span class="label label-danger">Not Active</span>
      <?php else: ?>
      <span class="label label-success">Active</span>
      <?php endif; ?>

      </td>
      <td><img src="<?php echo e(productImage($product->image)); ?>" height="60px" width="60px" alt=""></td>
      <td class="center" style="width: 100px;">
                        <div style="float: left;">
                        <a href='<?php echo e(route('sellUs.edit',$product->id)); ?>'>
                            <button class="btn btn-primary btn-xs">
                                <i class="fa fa-edit"></i>
                            </button>
                        </a>
                    </div>
                    <div style="float: right;">
                      <form action="<?php echo e(route('sellUs.delete',$product->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger btn-xs" onclick='confirm("Are you sure to delete?")'><i class="fa fa-trash"></i></button>
                      </form>
                        
                    </div>
                      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
      <td colspan="100%" align="center"><h2>No products found.</h2></td>
    </tr>
  <?php endif; ?>
  <?php echo e($products->links()); ?>

  </tbody>
  
</table>
</div>
</div>



    </main><!-- end MAIN -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>