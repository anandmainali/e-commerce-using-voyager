  

  <?php $__env->startSection('class'); ?>
  page-product grid-view <?php $__env->stopSection(); ?>

  <?php $__env->startSection('content'); ?>     


  <!-- MAIN -->
  <main class="site-main product-list product-grid">
    <div class="container">
        <ol class="breadcrumb-page">
            <li><a href="<?php echo e(route('/')); ?>">Home </a></li>
            <li class="active"><a href="#">Grid Categories  </a></li>
        </ol>
    </div>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-8 float-none float-right padding-left-5">
                <div class="main-content">

                    <div class="toolbar-products">
                        <h4 class="title-product"><?php echo e($categoryName); ?></h4>
                        <div class="toolbar-option">
                            <ul class="header-nav krystal-nav">
                            <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown" role="button" aria-expanded="false">Sort by Popularity <span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                          
                                    <li><a href="<?php echo e(route('shop.index',['category'=>request()->category,'sort'=>'latest'])); ?>">New Product</a></li>
                                    
                                    <li><a href="<?php echo e(route('shop.index',['category'=>request()->category,'sort'=>'low_high'])); ?>">Price Low to High</a></li>
                                    <li><a href="<?php echo e(route('shop.index',['category'=>request()->category,'sort'=>'high_low'])); ?>">Price High to Low</a></li>
                         
                        </ul>
                      </li>
                            

                            <div class="modes">
                                <a href="grid-product.html" class="active modes-mode mode-grid" title="Grid"><i class="flaticon-squares"></i>
                                    <span>Grid</span>
                                </a>
                                <a href="list-product.html" title="List" class="modes-mode mode-list"><i class="flaticon-interface"></i>
                                    <span>List</span>
                                </a>
                            </div>
                        </div>  
                    </div>
                    <div class="bestseller-and-deals-content border-background equal-container">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="product-item style1 col-md-4 col-sm-6 col-xs-6 padding-0">
                            <div class="product-inner equal-elem">
                                <div class="product-thumb">
                                    <div class="thumb-inner">
                                        <a href="<?php echo e(route('shop.show',$product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" alt="b2" style="height: 214px; width: 214px;"></a>
                                    </div>
                                    <?php if($product->discount): ?>
                                    <span class="onsale">-<?php echo e($product->discount); ?>%</span>
                                    <?php endif; ?>
                                   
                                </div>
                                <div class="product-innfo">
                                    <div class="product-name" style="height:60px"><a href="<?php echo e(route('shop.show',$product->slug)); ?>"><?php echo e($product->name); ?></a></div>
                                    <span class="price">
                                        <ins>Rs.<?php echo e($product->new_price); ?></ins>
                                        <?php if($product->old_price): ?>
                                        <del>Rs.<?php echo e($product->old_price); ?></del>
                                        <?php endif; ?>

                                    </span>
                                    <div class="group-btn-hover">
                                        <div class="inner">
                                            <div style="float: left;">
                                                <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                                    <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />    
                                                    <input type="hidden" name="price" value="<?php echo e($product->new_price); ?>" />
                                                    <input type="hidden" name="qty" value="1" />
                                                    <button type="submit" class="add-to-cart">Add to cart</button>
                                                </form>
                                            </div>
                                            <div style="float: right;">
                                                <form action="<?php echo e(route('wishlist.store',$product->id)); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                                    <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                                    <input type="hidden" name="price" value="<?php echo e($product->new_price); ?>" />
                                                    <button class="wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></button>

                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <br><br><br>
                        <div><h2>No items found.</h2></div>
                        <?php endif; ?>
                        <div class="pull-right">
                            <?php echo e($products->appends(request()->input())->links()); ?>

                        </div>

                    </div>  



                </div>


            </div>

            <div class="col-md-3 col-sm-4">
                <div class="col-sidebar">
                    <div class="filter-options">
                        <div class="block-title">Shop by</div>
                        <div class="block-content">


                            <div class="filter-options-item filter-price">
                                <div class="filter-options-title">Price</div>
                                <div class="filter-options-content">
                                    <div class="price_slider_wrapper">
                                        <div data-label-reasult="Price:" data-min="0" data-max="3000" data-unit="$" class="slider-range-price " data-value-min="85" data-value-max="2000">
                                            <span class="text-right">Filter</span>
                                        </div>
                                        <div class="price_slider_amount">
                                            <div class="price_label">
                                                Price: <span class="from">$85</span>-<span class="to">$2000</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>

                    <div class="block-latest-roducts">
                        <div class="block-title">Top Discount Products</div>
                        <div class="block-latest-roducts-content">
                            <div class="owl-carousel nav-style2" data-nav="true" data-autoplay="false" data-dots="false" data-loop="true" data-margin="0" data-responsive='{"0":{"items":1},"600":{"items":1},"1000":{"items":1}}'>
                                <div class="owl-ones-row">
                                    <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-item style1">
                                        <div class="product-inner">
                                            <div class="product-thumb">
                                                <div class="thumb-inner">
                                                    <a href="<?php echo e(route('shop.show',$product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" alt="p1" style="height: 80px; width: 80px;"></a>
                                                </div>
                                            </div>
                                            <div class="product-innfo">
                                                <div class="product-name"><a href="<?php echo e(route('shop.show',$product->slug)); ?>"><?php echo e($product->name); ?></a></div>
                                                <span class="price">
                                                    <ins>Rs.<?php echo e($product->new_price); ?></ins>
                                                    <?php if($product->old_price): ?>
                                                    <del>Rs.<?php echo e($product->old_price); ?></del>
                                                    <?php endif; ?>
                                                </span>
                                                <span class="star-rating">

                                                    <span class="review" style="color: white;">5 Review(s)</span>
                                                </span>
                                            </div>    
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                                <div class="owl-ones-row">
                                    <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-item style1">
                                        <div class="product-inner">
                                            <div class="product-thumb">
                                                <div class="thumb-inner">
                                                    <a href="<?php echo e(route('shop.show',$product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" alt="p1" style="height: 80px; width: 80px;"></a>
                                                </div>
                                            </div>
                                            <div class="product-innfo">
                                                <div class="product-name"><a href="<?php echo e(route('shop.show',$product->slug)); ?>"><?php echo e($product->name); ?></a></div>
                                                <span class="price">
                                                    <ins>Rs.<?php echo e($product->new_price); ?></ins>
                                                    <?php if($product->old_price): ?>
                                                    <del>Rs.<?php echo e($product->old_price); ?></del>
                                                    <?php endif; ?>
                                                </span>
                                                <span class="star-rating">

                                                    <span class="review" style="color: white;">5 Review(s)</span>
                                                </span>
                                            </div>    
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
    
    <?php echo $__env->make('includes.recommendation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</main><!-- end MAIN -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>