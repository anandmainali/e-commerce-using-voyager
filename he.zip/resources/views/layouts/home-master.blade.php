

@include('includes.header')

@include('includes.navbar')

<br>

	@yield('content')



@include('includes.footer')