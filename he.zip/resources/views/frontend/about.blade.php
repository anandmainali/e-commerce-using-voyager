@extends('layouts.home-master')


@section('content')

    <!--  about-page -->
    <div class="about">
        <div class="container">
            <h3 class="w3ls-title w3ls-title1">About Help Me</h3>
            <div class="about-text">
                <p style="color:black;">Helpme</p>
                
                <div class="clearfix"> </div>
            </div>
    
        </div>
    </div>
    <!-- //about-page -->

@endsection